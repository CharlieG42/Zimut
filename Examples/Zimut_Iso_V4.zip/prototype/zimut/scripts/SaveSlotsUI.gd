extends CanvasLayer
## SaveSlotsUI.gd — Écran de gestion des parties : 5 slots, équipe modifiable,
## inventaire de loots et équipement par personnage.

signal battle_requested(slot: int)

const COL_PANEL := Color(0.94, 0.89, 0.78, 0.97)
const COL_BORDER := Color(0.72, 0.58, 0.28, 1.0)
const COL_TXT := Color(0.22, 0.15, 0.05)

var _root: Control
var _slots_box: VBoxContainer
var _detail_panel: PanelContainer
var _detail_box: VBoxContainer
var _current: Dictionary = {}     # sauvegarde affichée dans le détail
var _current_slot: int = -1

func _ready() -> void:
	_build()

func _build() -> void:
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_root)
	var bg := ColorRect.new()
	bg.color = Color(0.06, 0.09, 0.14, 0.92)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(bg)

	var title := Label.new()
	title.text = "MES PARTIES (max %d)" % ProgressionManager.MAX_SAVES
	title.add_theme_font_size_override("font_size", 34)
	title.add_theme_color_override("font_color", COL_TXT)
	title.position = Vector2(40, 18)
	_root.add_child(title)

	var back := Button.new()
	back.text = "← MENU"
	back.position = Vector2(40, 18)
	back.custom_minimum_size = Vector2(160, 52)
	back.add_theme_font_size_override("font_size", 20)
	back.add_theme_color_override("font_color", COL_TXT)
	back.add_theme_stylebox_override("normal", _flat())
	back.pressed.connect(func() -> void:
		GameManager.active_save = {}
		GameManager.active_slot = -1
		get_tree().change_scene_to_file("res://scenes/MainMenu.tscn"))
	_root.add_child(back)

	_slots_box = VBoxContainer.new()
	_slots_box.position = Vector2(40, 90)
	_slots_box.custom_minimum_size = Vector2(560, 0)
	_slots_box.add_theme_constant_override("separation", 14)
	_root.add_child(_slots_box)

	_detail_panel = PanelContainer.new()
	_detail_panel.position = Vector2(640, 90)
	_detail_panel.custom_minimum_size = Vector2(600, 880)
	_detail_panel.add_theme_stylebox_override("panel", _flat())
	_root.add_child(_detail_panel)
	_detail_box = VBoxContainer.new()
	_detail_box.add_theme_constant_override("separation", 10)
	_detail_panel.add_child(_detail_box)

	refresh()

func _flat() -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = COL_PANEL
	s.border_color = COL_BORDER
	s.set_border_width_all(3)
	s.set_corner_radius_all(12)
	return s

func refresh() -> void:
	for c: Node in _slots_box.get_children():
		c.queue_free()
	var saves: Array = ProgressionManager.list_saves()
	var used: Dictionary = {}
	for sv: Dictionary in saves:
		used[int(sv["id"])] = sv
	for slot: int in range(ProgressionManager.MAX_SAVES):
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(560, 96)
		btn.add_theme_font_size_override("font_size", 22)
		btn.add_theme_color_override("font_color", COL_TXT)
		btn.add_theme_stylebox_override("normal", _flat())
		btn.add_theme_stylebox_override("hover", _flat())
		if used.has(slot):
			var sv: Dictionary = used[slot]
			btn.text = "%s — ennemis nv %d · %d victoires" % [sv["name"], sv["level"], sv["victories"]]
		else:
			btn.text = "+ Nouvelle partie (slot %d)" % (slot + 1)
		var slot_ref: int = slot
		btn.pressed.connect(func() -> void: _on_slot_pressed(slot_ref))
		_slots_box.add_child(btn)

	if _current_slot >= 0 and ProgressionManager.save_exists(_current_slot):
		_show_detail(ProgressionManager.load_save(_current_slot), _current_slot)

func _on_slot_pressed(slot: int) -> void:
	var data: Dictionary
	if ProgressionManager.save_exists(slot):
		data = ProgressionManager.load_save(slot)
	else:
		data = ProgressionManager.new_game(slot)
	_show_detail(data, slot)

func _show_detail(data: Dictionary, slot: int) -> void:
	_current = data
	_current_slot = slot
	for c: Node in _detail_box.get_children():
		c.queue_free()

	var title := Label.new()
	title.text = "%s — ennemis niveau %d" % [data.get("name", ""), int(data.get("level", 10))]
	title.add_theme_font_size_override("font_size", 26)
	title.add_theme_color_override("font_color", COL_TXT)
	_detail_box.add_child(title)

	# Looter / recadrer l'équipe : bouton vers TeamSelection
	var team_btn := Button.new()
	team_btn.text = "Changer l'équipe (libre à chaque combat)"
	team_btn.add_theme_font_size_override("font_size", 20)
	team_btn.add_theme_color_override("font_color", COL_TXT)
	team_btn.add_theme_stylebox_override("normal", _flat())
	team_btn.pressed.connect(func() -> void:
		_current = _current
		get_tree().change_scene_to_file("res://scenes/TeamSelection.tscn"))
	_detail_box.add_child(team_btn)

	# Renommer la partie
	var name_btn := Button.new()
	name_btn.text = "✎  RENOMMER CETTE PARTIE"
	name_btn.add_theme_font_size_override("font_size", 20)
	name_btn.add_theme_color_override("font_color", COL_TXT)
	name_btn.add_theme_stylebox_override("normal", _flat())
	name_btn.pressed.connect(func() -> void:
		var dialog := ConfirmationDialog.new()
		var line := LineEdit.new()
		line.text = String(data.get("name", ""))
		line.placeholder_text = "Nouveau nom"
		dialog.add_child(line)
		dialog.dialog_text = "Nouveau nom de la partie :"
		dialog.ok_button_text = "RENOMMER"
		dialog.cancel_button_text = "Annuler"
		dialog.confirmed.connect(func() -> void:
			ProgressionManager.rename_save(slot, line.text)
			_current = ProgressionManager.load_save(slot)
			refresh())
		dialog.register_text_enter(line)
		_root.add_child(dialog)
		dialog.popup_centered()
		line.call_deferred("grab_focus"))
	_detail_box.add_child(name_btn)

	# Supprimer la partie (avec confirmation)
	var del_btn := Button.new()
	del_btn.text = "🗑  SUPPRIMER CETTE PARTIE"
	del_btn.add_theme_font_size_override("font_size", 20)
	del_btn.add_theme_color_override("font_color", Color(0.35, 0.08, 0.05))
	del_btn.add_theme_stylebox_override("normal", _flat())
	del_btn.pressed.connect(func() -> void:
		var confirm := ConfirmationDialog.new()
		confirm.dialog_text = "Supprimer '%s' ?\nLa progression et l'inventaire seront perdus." % String(data.get("name", ""))
		confirm.ok_button_text = "SUPPRIMER"
		confirm.cancel_button_text = "Annuler"
		confirm.confirmed.connect(func() -> void:
			ProgressionManager.delete_save(slot)
			if GameManager.active_slot == slot:
				GameManager.active_save = {}
				GameManager.active_slot = -1
			_current = {}
			_current_slot = -1
			refresh())
		_root.add_child(confirm)
		confirm.popup_centered())
	_detail_box.add_child(del_btn)

	# Combat : lance la partie active
	var fight_btn := Button.new()
	fight_btn.text = "COMBAT — ennemis niveau %d" % int(data.get("level", 10))
	fight_btn.add_theme_font_size_override("font_size", 24)
	fight_btn.add_theme_color_override("font_color", COL_TXT)
	fight_btn.add_theme_stylebox_override("normal", _flat())
	fight_btn.pressed.connect(func() -> void:
		# Activer la partie (ennemis au niveau de la partie) et lancer le combat
		GameManager.active_save = _current
		GameManager.active_slot = slot
		battle_requested.emit(slot)
		get_tree().change_scene_to_file("res://scenes/TeamSelection.tscn"))
	_detail_box.add_child(fight_btn)

	# Équipe et équipement
	var team: Array = data.get("team", [])
	var team_lbl := Label.new()
	team_lbl.text = "Équipe :"
	team_lbl.add_theme_font_size_override("font_size", 22)
	team_lbl.add_theme_color_override("font_color", COL_TXT)
	_detail_box.add_child(team_lbl)
	for i: int in range(team.size()):
		var m: Dictionary = team[i]
		var row := Label.new()
		row.text = "  %s niv %d — %d objet(s) équipé(s)" % [m.get("classe", "?"),
			ProgressionManager.member_level(data, String(m.get("classe", ""))), _equip_summary(m).size()]
		row.add_theme_font_size_override("font_size", 18)
		row.add_theme_color_override("font_color", COL_TXT)
		_detail_box.add_child(row)

	var chars_btn := Button.new()
	chars_btn.text = "📈  PERSONNAGES — niveaux et caractéristiques"
	chars_btn.add_theme_font_size_override("font_size", 20)
	chars_btn.add_theme_color_override("font_color", COL_TXT)
	chars_btn.add_theme_stylebox_override("normal", _flat())
	chars_btn.pressed.connect(func() -> void:
		var ui: CanvasLayer = (load("res://scripts/CharacterSheetUI.gd") as GDScript).new()
		ui.layer = 10
		add_child(ui)
		ui.closed.connect(func() -> void:
			ui.queue_free()
			_show_detail(ProgressionManager.load_save(slot), slot))
		ui.open(_current, slot))
	_detail_box.add_child(chars_btn)

	# Inventaire
	var inv: Array = data.get("inventory", [])
	var inv_lbl := Label.new()
	inv_lbl.text = "Inventaire (%d objets disponibles à équiper) :" % inv.size()
	inv_lbl.add_theme_font_size_override("font_size", 22)
	inv_lbl.add_theme_color_override("font_color", COL_TXT)
	_detail_box.add_child(inv_lbl)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(560, 360)
	_detail_box.add_child(scroll)
	var inv_box := VBoxContainer.new()
	inv_box.add_theme_constant_override("separation", 6)
	scroll.add_child(inv_box)
	for j: int in range(inv.size()):
		var it: Dictionary = inv[j]
		var row2 := Label.new()
		row2.text = "  [%s] %s (nv%d) %s" % [ItemRules.rarity_label(it), it.get("name", "?"),
			int(it.get("level", 0)), ItemRules.stat_line(it)]
		row2.tooltip_text = ItemRules.describe(it)
		row2.mouse_filter = Control.MOUSE_FILTER_PASS
		row2.add_theme_font_size_override("font_size", 16)
		row2.add_theme_color_override("font_color", ItemRules.rarity_color(it).darkened(0.4))
		inv_box.add_child(row2)
	# Journal des loots gagnés (historique complet de la partie)
	var log_arr: Array = data.get("loot_log", [])
	if log_arr.size() > 0:
		var log_btn := Button.new()
		log_btn.text = "Voir tous les loots gagnés (%d)" % log_arr.size()
		log_btn.add_theme_font_size_override("font_size", 20)
		log_btn.add_theme_color_override("font_color", COL_TXT)
		log_btn.add_theme_stylebox_override("normal", _flat())
		log_btn.pressed.connect(func() -> void: _show_loot_log(log_arr))
		_detail_box.add_child(log_btn)

	# Équiper : simple boucle d'équipement auto sur l'équipe en place
	var auto_btn := Button.new()
	auto_btn.text = "Équiper automatiquement les meilleurs objets"
	auto_btn.add_theme_font_size_override("font_size", 20)
	auto_btn.add_theme_color_override("font_color", COL_TXT)
	auto_btn.add_theme_stylebox_override("normal", _flat())
	auto_btn.pressed.connect(_auto_equip)
	_detail_box.add_child(auto_btn)

func _equip_summary(m: Dictionary) -> Dictionary:
	return m.get("equipment", {})

func _auto_equip() -> void:
	if _current.is_empty():
		return
	ProgressionManager.auto_equip(_current)
	ProgressionManager.write_save(_current_slot, _current)
	_show_detail(ProgressionManager.load_save(_current_slot), _current_slot)


func _show_loot_log(log_arr: Array) -> void:
	# Fenêtre centrée sur l'écran, avec voile sombre cliquable (ferme la fenêtre)
	var overlay := ColorRect.new()
	overlay.color = Color(0, 0, 0, 0.55)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	_root.add_child(overlay)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	var dialog := PanelContainer.new()
	dialog.add_theme_stylebox_override("panel", _flat())
	center.add_child(dialog)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	dialog.add_child(box)
	var title := Label.new()
	title.text = "LOOTS GAGNÉS DANS CETTE PARTIE (%d)" % log_arr.size()
	title.add_theme_font_size_override("font_size", 24)
	title.add_theme_color_override("font_color", COL_TXT)
	box.add_child(title)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(520, 520)
	box.add_child(scroll)
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 6)
	scroll.add_child(rows)
	for it: Dictionary in log_arr:
		var row := Label.new()
		row.text = "✦ [%s] %s (nv%d) %s" % [ItemRules.rarity_label(it), it.get("name", "?"),
			int(it.get("level", 0)), ItemRules.stat_line(it)]
		row.add_theme_font_size_override("font_size", 17)
		row.add_theme_color_override("font_color", ItemRules.rarity_color(it).darkened(0.4))
		rows.add_child(row)
	var close := Button.new()
	close.text = "Fermer"
	close.add_theme_font_size_override("font_size", 20)
	close.add_theme_color_override("font_color", COL_TXT)
	close.add_theme_stylebox_override("normal", _flat())
	close.pressed.connect(overlay.queue_free)
	box.add_child(close)

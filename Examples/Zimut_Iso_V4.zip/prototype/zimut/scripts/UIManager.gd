extends CanvasLayer
## UIManager.gd — Interface de combat façon Waven / Dofus.
##   • Timeline d'initiative en portraits (haut)
##   • Panneau du personnage actif : PV, orbes PA / PM (bas-gauche)
##   • Barre de sorts défilante avec coûts, raccourcis 1-9 et infobulle (bas-centre)
##   • Gros bouton « FIN DU TOUR », Auto, Son, changement d'équipe (bas-droite)
##   • Journal de combat, bannières de tour, fiche de survol, écran de fin
## Toute l'interface est construite par code (les anciens nœuds de la scène sont masqués).

signal end_turn_requested
signal restart_requested
signal spell_selected(spell)

const COL_PANEL := Color(0.94, 0.89, 0.78, 0.94)
const COL_BORDER := Color(0.72, 0.58, 0.28, 1.0)
const COL_PLAYER := Color(0.22, 0.45, 0.85)
const COL_ENEMY := Color(0.80, 0.22, 0.20)
const COL_SUMMON := Color(0.25, 0.70, 0.45)

var game_manager: Node
var _grid: Node

var _root: Control
var _timeline: Control
var _stats: Control
var _spell_scroll: ScrollContainer
var _spell_box: VBoxContainer
var _tip_panel: PanelContainer
var _tip_label: Label
var _end_btn: Button
var _auto_btn: Button
var _sound_btn: Button
var _log_box: VBoxContainer
var _banner: Label
var _info_panel: PanelContainer
var _info_label: Label
var _over: ColorRect
var _over_title: Label
var _over_sub: Label
var _cards: Array = []
var _cards_owner: int = -1


# ═══════════════════════════════════════════════════════════════════════════
#  Cartes de sorts
# ═══════════════════════════════════════════════════════════════════════════

class SpellCard extends Button:
	## Carte de sort lisible d'un coup d'œil :
	##   pastille PA (bleu) en haut à gauche, PM (vert) en haut à droite si le sort en coûte,
	##   pastille PORTÉE (or) en bas à droite ; niveau du sort, zone et lancers restants
	##   en petites étiquettes en bas.
	var spell: Dictionary = {}
	var gm: Node = null
	var hotkey: int = 0
	var base_col: Color = Color(0.5, 0.2, 0.2)
	var selected: bool = false
	var usable: bool = true

	## Pastille ronde : valeur en gros, légende en petit à côté.
	func _orb(c: Vector2, r: float, val: String, col: Color) -> void:
		var font: Font = ThemeDB.fallback_font
		var base: Color = col if usable else Color(0.34, 0.37, 0.44)
		draw_circle(c + Vector2(0, 2.5), r + 1.5, Color(0, 0, 0, 0.55))
		draw_circle(c, r + 1.5, Color(0.02, 0.03, 0.07, 1.0))
		draw_circle(c, r - 0.5, base.darkened(0.30))
		draw_circle(c + Vector2(0, -r * 0.14), r - 3.0, base)
		draw_circle(c + Vector2(-r * 0.22, -r * 0.42), r * 0.34, Color(1, 1, 1, 0.30))
		var fs: int = 26 if val.length() <= 1 else (23 if val.length() == 2 else 15)
		var pos := Vector2(c.x - r, c.y + float(fs) * 0.36)
		draw_string_outline(font, pos, val, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, 6, Color(0, 0, 0, 0.9))
		draw_string(font, pos, val, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color.WHITE)

	func _caption(pos: Vector2, w: float, txt: String, col: Color, align: int = HORIZONTAL_ALIGNMENT_CENTER) -> void:
		var font: Font = ThemeDB.fallback_font
		draw_string_outline(font, pos, txt, align, w, 12, 4, Color(0, 0, 0, 0.9))
		draw_string(font, pos, txt, align, w, 12, col.lightened(0.55) if usable else Color(0.6, 0.62, 0.68))

	## Étiquette arrondie ; retourne l'abscisse de fin.
	func _pill(x: float, y: float, txt: String, col: Color) -> float:
		var font: Font = ThemeDB.fallback_font
		var w: float = font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 13).x + 12.0
		var rc := Rect2(x, y - 14.0, w, 18.0)
		draw_rect(rc, Color(0.02, 0.03, 0.08, 0.92))
		draw_rect(Rect2(rc.position, Vector2(3.0, rc.size.y)), col if usable else Color(0.4, 0.42, 0.48))
		draw_string(font, rc.position + Vector2(8, 13), txt, HORIZONTAL_ALIGNMENT_LEFT, w, 13, col.lightened(0.5) if usable else Color(0.62, 0.64, 0.7))
		return x + w + 4.0

	func _draw() -> void:
		var font: Font = ThemeDB.fallback_font
		# Liseré gauche de la couleur du type (rouge attaque / bleu buff / vert soin / jaune debuff)
		draw_rect(Rect2(0, 6, 5, size.y - 12), base_col if usable else base_col.darkened(0.4))
		var p: Dictionary = Combat.parse(spell)
		# PA en haut à gauche
		_orb(Vector2(27, 27), 19.0, str(int(spell.get("cost_pa", 0))), Color(0.16, 0.50, 0.95))
		_caption(Vector2(8, 58), 38.0, "PA", Color(0.16, 0.50, 0.95))
		# PM en haut à droite (seulement si le sort en coûte)
		if int(spell.get("cost_pm", 0)) > 0:
			_orb(Vector2(size.x - 27, 27), 19.0, str(int(spell["cost_pm"])), Color(0.14, 0.64, 0.32))
			_caption(Vector2(size.x - 46, 58), 38.0, "PM", Color(0.14, 0.64, 0.32))
		# Portée en bas à droite
		var rng: int = int(spell.get("range", 1))
		var rtxt: String = str(rng) if rng < 99 else "∞"
		if String(p["target"]) == "self":
			rtxt = "0"
		_orb(Vector2(size.x - 27, size.y - 27), 17.0, rtxt, Color(0.86, 0.66, 0.16))
		_caption(Vector2(size.x - 108, size.y - 20), 58.0, "Portée" if String(p["target"]) != "self" else "Sur soi",
			Color(0.86, 0.66, 0.16), HORIZONTAL_ALIGNMENT_RIGHT)
		# Rangée du bas : touche, niveau de sort, zone, lancers restants
		var x: float = 10.0
		if hotkey > 0:
			draw_rect(Rect2(x, size.y - 24, 18, 18), Color(0.02, 0.03, 0.08, 0.92))
			draw_string(font, Vector2(x, size.y - 10), str(hotkey % 10), HORIZONTAL_ALIGNMENT_CENTER, 18, 14, Color(1, 0.95, 0.6))
			x += 22.0
		var slvl: int = int(spell.get("spell_level", 1))
		if slvl > 1:
			x = _pill(x, size.y - 10, "★%d" % slvl, Color(1.0, 0.72, 0.18))
		var zone_txt: String = ""
		match String(p["aoe"]):
			"zone":
				zone_txt = "Zone %d" % int(p["zone_r"])
			"adjacent_enemies":
				zone_txt = "Autour"
			"team":
				zone_txt = "Équipe"
		if zone_txt != "" and x < size.x - 120.0:
			x = _pill(x, size.y - 10, zone_txt, Color(1.0, 0.6, 0.3))
		if gm != null and gm.active_entity.size() > 0:
			var left: int = gm.casts_left(gm.active_entity, spell)
			if left < Combat.max_casts(spell) and left >= 0 and x < size.x - 100.0:
				x = _pill(x, size.y - 10, "×%d" % left, Color(0.9, 0.9, 0.5))


func _flat(bg: Color, border: Color, radius: int = 14, bw: int = 3) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.shadow_color = Color(0, 0, 0, 0.45)
	s.shadow_size = 6
	return s


func _kind_color(spell: Dictionary) -> Color:
	## Code couleur uniforme :
	##   rouge = attaque, bleu = buff, vert = soin, jaune = debuff
	var p: Dictionary = Combat.parse(spell)
	var kind: String = String(p["kind"])
	if p["debuffs"].size() > 0 or spell.get("spell_type", "") == "Debuff":
		return Color(0.98, 0.82, 0.25)
	match kind:
		"heal":
			return Color(0.36, 0.78, 0.42)
		"buff":
			return Color(0.40, 0.60, 0.95)
		"summon", "teleport", "revive", "trap":
			return Color(0.40, 0.60, 0.95)
	return Color(0.92, 0.30, 0.25)


# ═══════════════════════════════════════════════════════════════════════════
#  Vues dessinées (timeline, panneau de personnage)
# ═══════════════════════════════════════════════════════════════════════════

class TimelineView extends Control:
	var gm: Node = null

	func _process(_d: float) -> void:
		queue_redraw()

	func _draw() -> void:
		if gm == null or gm.turn_order.is_empty():
			return
		var font: Font = ThemeDB.fallback_font
		# Ordre à partir de l'entité active
		var order: Array = []
		var start: int = 0
		for i: int in range(gm.turn_order.size()):
			if int(gm.turn_order[i]["uid"]) == int(gm.active_entity.get("uid", -1)):
				start = i
				break
		for k: int in range(gm.turn_order.size()):
			var e: Dictionary = gm.turn_order[(start + k) % gm.turn_order.size()]
			if gm.is_alive(e):
				order.append(e)
		var total_w: float = 0.0
		for k: int in range(order.size()):
			total_w += (96.0 if k == 0 else 74.0) + 8.0
		var x: float = (size.x - total_w) * 0.5
		for k: int in range(order.size()):
			var e2: Dictionary = order[k]
			var big: bool = (k == 0)
			var w: float = 96.0 if big else 74.0
			var y: float = 6.0
			var team_col: Color = Color(0.22, 0.45, 0.85)
			if e2["entity_type"] == "Summon":
				team_col = Color(0.25, 0.70, 0.45)
			elif e2["team"] == "enemy":
				team_col = Color(0.80, 0.22, 0.20)
			var bg := StyleBoxFlat.new()
			bg.bg_color = team_col.darkened(0.55)
			bg.border_color = Color(1.0, 0.85, 0.25) if big else team_col.lightened(0.15)
			bg.set_border_width_all(4 if big else 3)
			bg.set_corner_radius_all(14)
			bg.shadow_color = Color(0, 0, 0, 0.5)
			bg.shadow_size = 5
			var rect := Rect2(x, y, w, w)
			draw_style_box(bg, rect)
			var tex: Texture2D = Portraits.get_texture(e2)
			if tex != null:
				draw_texture_rect_region(tex, rect.grow(-6.0), Portraits.head_region(tex))
			else:
				var col: Color = e2.get("color", Color(0.6, 0.6, 0.6))
				draw_circle(rect.get_center(), w * 0.32, col)
				draw_string(font, rect.position + Vector2(0, w * 0.6), String(e2["classe"]).substr(0, 3), HORIZONTAL_ALIGNMENT_CENTER, w, 20, Color.WHITE)
			# Barre de vie
			var ratio: float = clampf(float(e2["current_pv"]) / maxf(1.0, float(e2["max_pv"])), 0.0, 1.0)
			var hb := Rect2(x + 4.0, y + w - 10.0, w - 8.0, 7.0)
			draw_rect(hb, Color(0, 0, 0, 0.8))
			draw_rect(Rect2(hb.position, Vector2(hb.size.x * ratio, hb.size.y)), Color(0.35, 0.9, 0.4) if e2["team"] == "player" else Color(0.95, 0.3, 0.25))
			if big:
				draw_string_outline(font, Vector2(x, y + w + 20.0), String(e2["classe"]), HORIZONTAL_ALIGNMENT_CENTER, w, 16, 5, Color(0, 0, 0, 0.9))
				draw_string(font, Vector2(x, y + w + 20.0), String(e2["classe"]), HORIZONTAL_ALIGNMENT_CENTER, w, 16, Color(1, 0.95, 0.75))
			x += w + 8.0


class StatsView extends Control:
	var gm: Node = null

	func _process(_d: float) -> void:
		queue_redraw()

	func _orb(c: Vector2, r: float, dark: Color, light: Color, text: String, label: String) -> void:
		var font: Font = ThemeDB.fallback_font
		draw_circle(c, r + 5.0, Color(1, 1, 1, 0.85))
		draw_circle(c, r + 2.0, Color(0.02, 0.04, 0.1))
		draw_circle(c, r, dark)
		draw_circle(c + Vector2(0, -r * 0.18), r * 0.8, light)
		draw_circle(c + Vector2(-r * 0.3, -r * 0.45), r * 0.28, Color(1, 1, 1, 0.3))
		draw_string_outline(font, c + Vector2(-r, 14.0), text, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 40, 8, Color(0, 0, 0, 0.8))
		draw_string(font, c + Vector2(-r, 14.0), text, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 40, Color.WHITE)
		draw_string_outline(font, c + Vector2(-r, r + 24.0), label, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 16, 5, Color(0, 0, 0, 0.9))
		draw_string(font, c + Vector2(-r, r + 24.0), label, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 16, Color(0.85, 0.92, 1.0))

	func _draw() -> void:
		if gm == null or gm.active_entity.is_empty():
			return
		var e: Dictionary = gm.active_entity
		var font: Font = ThemeDB.fallback_font
		var team_col: Color = Color(0.36, 0.52, 0.85) if e["team"] == "player" else Color(0.85, 0.3, 0.28)
		var bg := StyleBoxFlat.new()
		bg.bg_color = Color(0.07, 0.09, 0.15, 0.90)
		bg.border_color = team_col
		bg.set_border_width_all(3)
		bg.set_corner_radius_all(20)
		bg.shadow_color = Color(0, 0, 0, 0.5)
		bg.shadow_size = 8
		draw_style_box(bg, Rect2(Vector2.ZERO, size))
		var pr := Rect2(16, 18, 140, 140)
		var pbg := StyleBoxFlat.new()
		pbg.bg_color = team_col.darkened(0.6)
		pbg.border_color = Color(1, 0.85, 0.3)
		pbg.set_border_width_all(4)
		pbg.set_corner_radius_all(16)
		draw_style_box(pbg, pr)
		var tex: Texture2D = Portraits.get_texture(e)
		if tex != null:
			draw_texture_rect_region(tex, pr.grow(-6.0), Portraits.head_region(tex))
		else:
			draw_circle(pr.get_center(), 46.0, e.get("color", Color(0.6, 0.6, 0.6)))
		draw_string(font, Vector2(172, 40), String(e["name"]), HORIZONTAL_ALIGNMENT_LEFT, 360, 26, Color(1, 0.95, 0.8))
		var hb := Rect2(172, 52, 350, 24)
		draw_rect(hb.grow(2.0), Color(0, 0, 0, 0.85))
		var ratio: float = clampf(float(e["current_pv"]) / maxf(1.0, float(e["max_pv"])), 0.0, 1.0)
		draw_rect(Rect2(hb.position, Vector2(hb.size.x * ratio, hb.size.y)), Color(0.3, 0.85, 0.35) if e["team"] == "player" else Color(0.9, 0.28, 0.25))
		draw_rect(Rect2(hb.position, Vector2(hb.size.x * ratio, hb.size.y * 0.4)), Color(1, 1, 1, 0.2))
		draw_string_outline(font, hb.position + Vector2(0, 19), "%d / %d" % [int(e["current_pv"]), int(e["max_pv"])], HORIZONTAL_ALIGNMENT_CENTER, hb.size.x, 18, 5, Color(0, 0, 0, 0.9))
		draw_string(font, hb.position + Vector2(0, 19), "%d / %d" % [int(e["current_pv"]), int(e["max_pv"])], HORIZONTAL_ALIGNMENT_CENTER, hb.size.x, 18, Color.WHITE)
		_orb(Vector2(232, 118), 36.0, Color(0.05, 0.25, 0.65), Color(0.2, 0.62, 1.0), "%d" % int(e["current_pa"]), "PA")
		_orb(Vector2(328, 118), 36.0, Color(0.05, 0.4, 0.15), Color(0.25, 0.8, 0.35), "%d" % int(e["current_pm"]), "PM")
		draw_string(font, Vector2(400, 112), "Tour %d" % int(gm.turn_count), HORIZONTAL_ALIGNMENT_LEFT, 130, 22, Color(0.8, 0.88, 1.0))
		var rest: String = "Votre tour" if gm.current_turn == 0 else ("Auto…" if gm.auto_mode else "Tour adverse")
		draw_string(font, Vector2(400, 140), rest, HORIZONTAL_ALIGNMENT_LEFT, 130, 16, Color(1, 0.85, 0.4) if gm.current_turn == 0 else Color(1, 0.55, 0.5))


# ═══════════════════════════════════════════════════════════════════════════
#  Construction
# ═══════════════════════════════════════════════════════════════════════════

func init(manager: Node) -> void:
	game_manager = manager
	_grid = get_node_or_null("../GridManager")
	# Masque l'ancienne interface de la scène
	for c: Node in get_children():
		if c is CanvasItem:
			(c as CanvasItem).visible = false
	_build_ui()
	_connect_signals()


func _connect_signals() -> void:
	game_manager.turn_started.connect(_on_turn_started)
	game_manager.state_changed.connect(_refresh)
	game_manager.spell_selected.connect(_on_spell_state)
	game_manager.message_requested.connect(_on_message)
	game_manager.game_ended.connect(_on_game_ended)
	game_manager.fx.connect(_on_fx)
	if _grid != null and _grid.has_signal("hover_changed"):
		_grid.hover_changed.connect(_on_hover)


func _build_ui() -> void:
	_root = Control.new()
	_root.name = "HUD"
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	# Timeline
	var tl := TimelineView.new()
	tl.gm = game_manager
	tl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tl.anchor_left = 0.5
	tl.anchor_right = 0.5
	tl.offset_left = -800.0
	tl.offset_right = 800.0
	tl.offset_top = 6.0
	tl.offset_bottom = 140.0
	_root.add_child(tl)
	_timeline = tl

	# Panneau du personnage actif
	var st := StatsView.new()
	st.gm = game_manager
	st.mouse_filter = Control.MOUSE_FILTER_IGNORE
	st.anchor_top = 1.0
	st.anchor_bottom = 1.0
	st.offset_left = 18.0
	st.offset_right = 568.0
	st.offset_top = -214.0
	st.offset_bottom = -18.0
	_root.add_child(st)
	_stats = st

	# Barre de sorts
	_spell_scroll = ScrollContainer.new()
	_spell_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_spell_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	_spell_scroll.anchor_left = 0.0
	_spell_scroll.anchor_right = 0.0
	_spell_scroll.anchor_top = 0.0
	_spell_scroll.anchor_bottom = 1.0
	_spell_scroll.offset_left = 12.0
	_spell_scroll.offset_right = 256.0
	_spell_scroll.offset_top = 12.0
	_spell_scroll.offset_bottom = -12.0
	_root.add_child(_spell_scroll)
	_spell_box = VBoxContainer.new()
	_spell_box.add_theme_constant_override("separation", 12)
	_spell_scroll.add_child(_spell_box)

	# Infobulle de sort
	_tip_panel = PanelContainer.new()
	_tip_panel.add_theme_stylebox_override("panel", _flat(Color(0.06, 0.08, 0.14, 0.95), Color(1, 0.85, 0.35), 14, 2))
	_tip_panel.anchor_left = 0.0
	_tip_panel.anchor_right = 0.0
	_tip_panel.anchor_top = 0.0
	_tip_panel.anchor_bottom = 0.0
	_tip_panel.offset_left = 276.0
	_tip_panel.offset_right = 696.0
	_tip_panel.offset_top = 14.0
	_tip_panel.offset_bottom = 150.0
	_tip_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tip_panel.visible = false
	_tip_label = Label.new()
	_tip_label.add_theme_font_size_override("font_size", 22)
	_tip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_tip_label.custom_minimum_size = Vector2(420, 0)
	_tip_panel.add_child(_tip_label)
	_root.add_child(_tip_panel)

	# Bouton fin de tour
	_end_btn = Button.new()
	_end_btn.text = "FIN DU\nTOUR"
	_end_btn.add_theme_font_size_override("font_size", 30)
	_end_btn.add_theme_color_override("font_color", Color(0.25, 0.18, 0.08))
	_end_btn.add_theme_color_override("font_hover_color", Color(0.15, 0.1, 0.02))
	_end_btn.add_theme_stylebox_override("normal", _flat(Color(0.98, 0.86, 0.45), Color(0.72, 0.58, 0.28), 40, 5))
	_end_btn.add_theme_stylebox_override("hover", _flat(Color(1.0, 0.92, 0.6), Color(0.85, 0.68, 0.3), 40, 5))
	_end_btn.add_theme_stylebox_override("pressed", _flat(Color(0.9, 0.76, 0.35), Color(0.6, 0.48, 0.2), 40, 5))
	_end_btn.add_theme_stylebox_override("disabled", _flat(Color(0.12, 0.14, 0.2), Color(0.3, 0.35, 0.45), 40, 5))
	_end_btn.anchor_left = 1.0
	_end_btn.anchor_right = 1.0
	_end_btn.anchor_top = 1.0
	_end_btn.anchor_bottom = 1.0
	_end_btn.offset_left = -330.0
	_end_btn.offset_right = -22.0
	_end_btn.offset_top = -170.0
	_end_btn.offset_bottom = -24.0
	_end_btn.pressed.connect(func() -> void:
		Sfx.play("click")
		end_turn_requested.emit())
	_root.add_child(_end_btn)

	# Boutons secondaires
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.anchor_left = 1.0
	row.anchor_right = 1.0
	row.anchor_top = 1.0
	row.anchor_bottom = 1.0
	row.offset_left = -330.0
	row.offset_right = -22.0
	row.offset_top = -236.0
	row.offset_bottom = -182.0
	_root.add_child(row)
	_auto_btn = _small_button("Auto", true)
	_auto_btn.toggled.connect(func(on: bool) -> void:
		Sfx.play("click")
		game_manager.set_auto(on))
	row.add_child(_auto_btn)
	_sound_btn = _small_button("Son : oui", true)
	_sound_btn.button_pressed = Sfx.enabled
	_sound_btn.toggled.connect(func(on: bool) -> void:
		Sfx.enabled = on
		_sound_btn.text = "Son : oui" if on else "Son : non"
		Sfx.play("click"))
	row.add_child(_sound_btn)
	var team_btn: Button = _small_button("Équipe", false)
	team_btn.pressed.connect(_on_team_selection_pressed)
	row.add_child(team_btn)

	# Journal de combat
	_log_box = VBoxContainer.new()
	_log_box.add_theme_constant_override("separation", 2)
	_log_box.position = Vector2(276, 160)
	_log_box.size = Vector2(560, 300)
	_log_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_log_box)

	# Bannière
	_banner = Label.new()
	_banner.add_theme_font_size_override("font_size", 64)
	_banner.add_theme_color_override("font_color", Color(1, 0.93, 0.6))
	_banner.add_theme_color_override("font_outline_color", Color(0.1, 0.05, 0.0, 0.95))
	_banner.add_theme_constant_override("outline_size", 14)
	_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_banner.anchor_left = 0.0
	_banner.anchor_right = 1.0
	_banner.offset_top = 190.0
	_banner.offset_bottom = 290.0
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.modulate.a = 0.0
	_root.add_child(_banner)

	# Fiche de survol
	_info_panel = PanelContainer.new()
	_info_panel.add_theme_stylebox_override("panel", _flat(COL_PANEL, COL_BORDER, 14, 2))
	_info_panel.anchor_left = 1.0
	_info_panel.anchor_right = 1.0
	_info_panel.offset_left = -330.0
	_info_panel.offset_right = -20.0
	_info_panel.offset_top = 160.0
	_info_panel.offset_bottom = 330.0
	_info_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_info_panel.visible = false
	_info_label = Label.new()
	_info_label.add_theme_font_size_override("font_size", 18)
	_info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_info_label.custom_minimum_size = Vector2(280, 0)
	_info_panel.add_child(_info_label)
	_root.add_child(_info_panel)

	# Écran de fin
	_over = ColorRect.new()
	_over.color = Color(0, 0, 0, 0.7)
	_over.set_anchors_preset(Control.PRESET_FULL_RECT)
	_over.visible = false
	_root.add_child(_over)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.anchor_left = 0.5
	box.anchor_right = 0.5
	box.anchor_top = 0.5
	box.anchor_bottom = 0.5
	box.offset_left = -300.0
	box.offset_right = 300.0
	box.offset_top = -200.0
	box.offset_bottom = 200.0
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 22)
	_over.add_child(box)
	_over_title = Label.new()
	_over_title.add_theme_font_size_override("font_size", 96)
	_over_title.add_theme_constant_override("outline_size", 16)
	_over_title.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.95))
	_over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_over_title)
	_over_sub = Label.new()
	_over_sub.add_theme_font_size_override("font_size", 28)
	_over_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_over_sub)
	var cont_btn: Button = _big_button("CONTINUER")
	if game_manager.active_save.is_empty() or game_manager.active_slot < 0:
		cont_btn.disabled = true
		cont_btn.tooltip_text = "Nécessite une partie active."
	cont_btn.pressed.connect(func() -> void:
		Sfx.play("click")
		get_tree().change_scene_to_file("res://scenes/TeamSelection.tscn"))
	box.add_child(cont_btn)
	var other: Button = _big_button("Changer d'équipe")
	other.pressed.connect(_on_team_selection_pressed)
	box.add_child(other)
	var saves_btn: Button = _big_button("Mes parties / Progression")
	saves_btn.pressed.connect(func() -> void:
		Sfx.play("click")
		get_tree().change_scene_to_file("res://scenes/SaveSlots.tscn"))
	box.add_child(saves_btn)


func _small_button(text: String, toggle: bool) -> Button:
	var b := Button.new()
	b.text = text
	b.toggle_mode = toggle
	b.custom_minimum_size = Vector2(96, 54)
	b.add_theme_font_size_override("font_size", 18)
	b.add_theme_stylebox_override("normal", _flat(Color(0.1, 0.13, 0.22, 0.92), Color(0.4, 0.5, 0.75), 12, 2))
	b.add_theme_stylebox_override("hover", _flat(Color(0.16, 0.2, 0.32, 0.95), Color(0.6, 0.75, 1.0), 12, 2))
	b.add_theme_stylebox_override("pressed", _flat(Color(0.5, 0.35, 0.08, 0.95), Color(1.0, 0.85, 0.3), 12, 2))
	return b


func _big_button(text: String) -> Button:
	var b := _small_button(text, false)
	b.custom_minimum_size = Vector2(380, 80)
	b.add_theme_font_size_override("font_size", 32)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	return b


# ═══════════════════════════════════════════════════════════════════════════
#  Mise à jour
# ═══════════════════════════════════════════════════════════════════════════

func _on_turn_started(e: Dictionary) -> void:
	_rebuild_spell_bar(e)
	var txt: String
	var col := Color(1, 0.93, 0.6)
	if e["entity_type"] == "Player" and not game_manager.auto_mode:
		txt = "%s — À vous de jouer !" % ProgressionManager.biome_label(game_manager.fight_biome)
		col = Color(0.65, 0.9, 1.0)
	else:
		txt = "Tour : %s" % e["name"]
		col = Color(1.0, 0.65, 0.55) if e["team"] == "enemy" else Color(0.7, 1.0, 0.75)
	_show_banner(txt, col)
	_refresh()


func _show_banner(text: String, col: Color) -> void:
	_banner.text = text
	_banner.add_theme_color_override("font_color", col)
	_banner.pivot_offset = Vector2(_banner.size.x * 0.5, 50.0)
	_banner.scale = Vector2(0.8, 0.8)
	_banner.modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.tween_property(_banner, "modulate:a", 1.0, 0.15)
	tw.parallel().tween_property(_banner, "scale", Vector2.ONE, 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(0.7)
	tw.tween_property(_banner, "modulate:a", 0.0, 0.35)


func _rebuild_spell_bar(e: Dictionary) -> void:
	for c: Node in _spell_box.get_children():
		c.queue_free()
	_cards = []
	_cards_owner = int(e["uid"])
	var idx: int = 0
	for spell: Dictionary in e["spells"]:
		idx += 1
		var card := SpellCard.new()
		card.spell = spell
		card.gm = game_manager
		card.hotkey = idx if idx <= 10 else 0
		card.base_col = _kind_color(spell)
		card.custom_minimum_size = Vector2(232, 92)
		card.text = String(spell["name"])
		var nlen: int = String(spell["name"]).length()
		card.add_theme_font_size_override("font_size", 21 if nlen <= 10 else (19 if nlen <= 15 else 17))
		card.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		card.add_theme_constant_override("outline_size", 5)
		card.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
		card.focus_mode = Control.FOCUS_NONE
		_style_card(card, false)
		card.pressed.connect(func() -> void: spell_selected.emit(spell))
		card.mouse_entered.connect(func() -> void: _show_tip(spell))
		card.mouse_exited.connect(func() -> void: _show_tip(game_manager.selected_spell))
		_spell_box.add_child(card)
		_cards.append(card)
	_spell_scroll.scroll_horizontal = 0


func _style_card(card: SpellCard, selected: bool) -> void:
	# Fond sombre (texte blanc lisible) teinté de la couleur du type ; bordure du type, or si sélectionné
	var tint: Color = card.base_col if card.usable else Color(0.45, 0.46, 0.50)
	var bg: Color = Color(0.08, 0.10, 0.16, 0.96).lerp(tint, 0.20 if card.usable else 0.06)
	var border: Color = Color(1.0, 0.9, 0.3) if selected else tint.lightened(0.15)
	var txt: Color = Color.WHITE if card.usable else Color(0.62, 0.64, 0.70)
	for key: String in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_disabled_color"]:
		card.add_theme_color_override(key, txt)
	card.add_theme_stylebox_override("normal", _card_box(bg, border, 5 if selected else 2))
	card.add_theme_stylebox_override("hover", _card_box(bg.lightened(0.10), Color(1, 1, 1, 0.9), 3))
	card.add_theme_stylebox_override("pressed", _card_box(bg.darkened(0.2), Color(1, 0.9, 0.3), 5))
	card.add_theme_stylebox_override("focus", _card_box(bg, border, 3))
	card.add_theme_stylebox_override("disabled", _card_box(bg.darkened(0.3), border, 2))


## Fond de carte : marges internes pour que le nom reste entre les pastilles.
func _card_box(bg: Color, border: Color, bw: int) -> StyleBoxFlat:
	var sb: StyleBoxFlat = _flat(bg, border, 14, bw)
	sb.content_margin_left = 50.0
	sb.content_margin_right = 50.0
	sb.content_margin_top = 8.0
	sb.content_margin_bottom = 26.0
	return sb


func _refresh() -> void:
	if game_manager == null or _root == null:
		return
	var e: Dictionary = game_manager.active_entity
	if not e.is_empty() and int(e["uid"]) != _cards_owner:
		_rebuild_spell_bar(e)
	var my_turn: bool = game_manager.current_turn == 0 and not game_manager.game_over
	for card: SpellCard in _cards:
		var usable: bool = false
		if not e.is_empty():
			usable = game_manager.can_afford(e, card.spell) and game_manager.casts_left(e, card.spell) > 0
		var sel: bool = game_manager.selected_spell != null and game_manager.selected_spell["name"] == card.spell["name"]
		if usable != card.usable or sel != card.selected:
			card.usable = usable
			card.selected = sel
			_style_card(card, sel)
		card.modulate = Color(1, 1, 1, 1.0 if my_turn else 0.5)
		card.queue_redraw()
	_end_btn.disabled = not my_turn
	_auto_btn.set_pressed_no_signal(game_manager.auto_mode)
	if _grid != null and _info_panel.visible and "hover_cell" in _grid:
		_on_hover(_grid.hover_cell)
	_spell_scroll.modulate = Color(1, 1, 1, 1.0)


func _on_spell_state(spell) -> void:
	_show_tip(spell)
	_refresh()


func _show_tip(spell) -> void:
	if spell == null:
		_tip_panel.visible = false
		return
	var p: Dictionary = Combat.parse(spell)
	var lines: Array[String] = []
	lines.append("%s" % spell["name"])
	var rng_txt: String = "Portée %d" % int(spell["range"]) if p["target"] != "self" else "Sur soi"
	var costs: String = "%d PA" % int(spell["cost_pa"])
	if int(spell.get("cost_pm", 0)) > 0:
		costs += " + %d PM" % int(spell["cost_pm"])
	lines.append("%s  ·  %s  ·  %d/tour" % [costs, rng_txt, Combat.max_casts(spell)])
	lines.append(Combat.describe(spell))
	var tip_lvl: int = int(spell.get("spell_level", 1))
	if tip_lvl > 1:
		lines.append("★ Niveau %d : +%d %% d'efficacité" % [tip_lvl, int(roundf((float(spell.get("mult", 1.0)) - 1.0) * 100.0))])
	if p["aoe"] == "zone":
		lines.append("Zone d'effet")
	if p["needs_los"]:
		lines.append("Ligne de vue requise")
	_tip_label.text = "\n".join(lines)
	_tip_panel.visible = true
	_tip_panel.reset_size()


func _on_message(text: String) -> void:
	if text == "" or _log_box == null:
		return
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 22)
	l.add_theme_color_override("font_color", Color(1, 1, 0.92))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.95))
	l.add_theme_constant_override("outline_size", 6)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(540, 0)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_log_box.add_child(l)
	while _log_box.get_child_count() > 6:
		var old: Node = _log_box.get_child(0)
		_log_box.remove_child(old)
		old.queue_free()
	var tw: Tween = create_tween()
	tw.tween_interval(5.0)
	tw.tween_property(l, "modulate:a", 0.0, 1.2)
	tw.tween_callback(l.queue_free)


func _on_fx(kind: String, _d: Dictionary) -> void:
	if kind == "banner":
		_show_banner(String(_d.get("text", "")), Color(1, 0.9, 0.5))


func _on_hover(cell: Vector2i) -> void:
	if game_manager == null:
		return
	var e: Dictionary = game_manager.entity_at(cell)
	if e.is_empty():
		_info_panel.visible = false
		return
	var lines: Array[String] = [String(e["name"])]
	lines.append("PV %d / %d" % [int(e["current_pv"]), int(e["max_pv"])])
	lines.append("PA %d · PM %d · Déf %d" % [int(e["max_pa"]), int(e["max_pm"]), int(e["defense"])])
	for s: Dictionary in e["statuses"]:
		var info: Dictionary = Combat.status_info(String(s["id"]))
		var t: String = "" if int(s["turns"]) > 90 else " (%d t.)" % int(s["turns"])
		lines.append("• %s%s" % [info["label"], t])
	_info_label.text = "\n".join(lines)
	_info_panel.visible = true
	_info_panel.reset_size()


func _on_game_ended(victory: bool) -> void:
	await get_tree().create_timer(1.4).timeout
	if game_manager == null or not game_manager.game_over:
		return
	if not game_manager.active_save.is_empty() and not game_manager.active_save.get("last_result", {}).is_empty():
		_show_result_window(victory)
		return
	_show_game_over(victory)

func _show_game_over(victory: bool) -> void:
	Sfx.play("win" if victory else "lose")
	_over_title.text = "VICTOIRE !" if victory else "DÉFAITE"
	_over_title.add_theme_color_override("font_color", Color(1, 0.9, 0.35) if victory else Color(1, 0.35, 0.3))
	_over_sub.text = "Combat terminé en %d tours" % int(game_manager.turn_count)
	_over.visible = true
	_over.modulate.a = 0.0
	create_tween().tween_property(_over, "modulate:a", 1.0, 0.5)

## Fenêtre de résultat (XP, niveaux gagnés, nouveaux sorts, loots avec rareté),
## affichée avant l'écran de fin de combat.
func _show_result_window(victory: bool) -> void:
	var save: Dictionary = game_manager.active_save
	var res: Dictionary = save.get("last_result", {})
	var loots: Array = save.get("last_loots", []) if victory else []
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _flat(Color(0.94, 0.89, 0.78, 0.97), Color(0.72, 0.58, 0.28), 16, 4))
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.45)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	_root.add_child(dim)
	_root.add_child(panel)
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE, 0)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	panel.add_child(box)

	var title := Label.new()
	var fight_no: int = ProgressionManager.next_fight_number(save)
	var next_biome: String = ProgressionManager.biome_for_fight(fight_no)
	if not victory:
		title.text = "DÉFAITE — un peu d'XP de consolation"
	elif ProgressionManager.is_boss_fight(save):
		title.text = "VICTOIRE !  %s : ☠ BOSS %s et ses sbires au combat %d !" % [ProgressionManager.biome_label(next_biome), ProgressionManager.biome_boss(next_biome), fight_no]
	else:
		title.text = ("VICTOIRE (combat rejoué) !  " if bool(res.get("replay", false)) else "VICTOIRE !  ") + "%s : ennemis niveau %d au prochain combat (%d)" % [ProgressionManager.biome_label(next_biome), ProgressionManager.enemy_level_for(save), fight_no]
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color(0.22, 0.15, 0.05) if victory else Color(0.55, 0.12, 0.08))
	box.add_child(title)

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(1100, 520)
	box.add_child(scroll)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 6)
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(content)

	# ── XP par personnage ───────────────────────────────────────────────
	var xp_rep: Dictionary = res.get("xp", {})
	var bench: Array[String] = []
	var total_pts: int = 0
	for classe: String in ProgressionManager.class_names():
		if not xp_rep.has(classe):
			continue
		var r: Dictionary = xp_rep[classe]
		if not bool(r.get("in_team", false)):
			bench.append("%s +%d" % [classe, int(r["gain"])])
			continue
		var line := Label.new()
		var up: bool = int(r["to_level"]) > int(r["from_level"])
		line.text = "  %s   +%d XP   niveau %d%s" % [classe, int(r["gain"]),
			int(r["to_level"]), "  ▲ (était %d)" % int(r["from_level"]) if up else ""]
		line.add_theme_font_size_override("font_size", 24 if up else 21)
		line.add_theme_color_override("font_color", Color(0.10, 0.45, 0.12) if up else Color(0.30, 0.22, 0.08))
		content.add_child(line)
		var bar := ProgressBar.new()
		bar.custom_minimum_size = Vector2(1000, 14)
		bar.min_value = 0.0
		bar.max_value = float(maxi(1, int(r["xp_next"]) - int(r["xp_cur"])))
		bar.value = clampf(float(int(r["xp"]) - int(r["xp_cur"])), 0.0, bar.max_value)
		bar.show_percentage = false
		content.add_child(bar)
		if int(r["points"]) > 0:
			total_pts += int(r["points"])
			var pl := Label.new()
			pl.text = "      ✦ +%d points de caractéristiques" % int(r["points"])
			pl.add_theme_font_size_override("font_size", 18)
			pl.add_theme_color_override("font_color", Color(0.15, 0.40, 0.55))
			content.add_child(pl)
		var spells: Array = r.get("spells", [])
		if not spells.is_empty():
			var sl := Label.new()
			sl.text = "      ★ Nouveau(x) sort(s) : %s" % ", ".join(PackedStringArray(spells))
			sl.add_theme_font_size_override("font_size", 18)
			sl.add_theme_color_override("font_color", Color(0.55, 0.30, 0.60))
			content.add_child(sl)
	if not bench.is_empty():
		var bl := Label.new()
		bl.text = "  Hors équipe : %s" % " · ".join(PackedStringArray(bench))
		bl.add_theme_font_size_override("font_size", 16)
		bl.add_theme_color_override("font_color", Color(0.45, 0.36, 0.2))
		content.add_child(bl)
	if total_pts > 0:
		var hint := Label.new()
		hint.text = "  (Les points sont répartis automatiquement ; changez cela dans « Personnages ».)"
		hint.add_theme_font_size_override("font_size", 15)
		hint.add_theme_color_override("font_color", Color(0.45, 0.36, 0.2))
		content.add_child(hint)

	# ── Loots ───────────────────────────────────────────────────────────
	if victory:
		var lbl := Label.new()
		lbl.text = "Objets gagnés (%d) :" % loots.size() if not loots.is_empty() else "Aucun loot cette fois..."
		lbl.add_theme_font_size_override("font_size", 22)
		lbl.add_theme_color_override("font_color", Color(0.22, 0.15, 0.05))
		content.add_child(lbl)
		for it: Dictionary in loots:
			var row := Label.new()
			var fx_txt: String = " · ".join(PackedStringArray(ItemRules.fx_lines(ItemRules.parse_effect(String(it.get("effect", ""))))))
			row.text = "  ✦ [%s] %s (nv%d) — %s%s" % [ItemRules.rarity_label(it), it.get("name", "?"), int(it.get("level", 0)),
				ItemRules.stat_line(it), ("  ✦ " + fx_txt) if fx_txt != "" else ""]
			row.tooltip_text = ItemRules.describe(it)
			row.mouse_filter = Control.MOUSE_FILTER_PASS
			row.add_theme_font_size_override("font_size", 19)
			row.add_theme_color_override("font_color", ItemRules.rarity_color(it).darkened(0.35))
			content.add_child(row)
		# Ressources de craft et or gagnés
		var drops: Dictionary = save.get("last_resources", {})
		if not drops.is_empty():
			var res_parts: PackedStringArray = []
			for k: String in drops.keys():
				res_parts.append("%s +%d" % [k, int(drops[k])])
			var res_row := Label.new()
			res_row.text = "  ⛏ Ressources : %s   ·   🪙 Or : %d" % [" · ".join(res_parts), ProgressionManager.gold(save)]
			res_row.add_theme_font_size_override("font_size", 19)
			res_row.add_theme_color_override("font_color", Color(0.35, 0.30, 0.15))
			res_row.tooltip_text = "À utiliser dans la FORGE (bouton ÉQUIPEMENT de la sélection d'équipe)."
			content.add_child(res_row)

	var cont := Button.new()
	cont.text = "CONTINUER"
	cont.custom_minimum_size = Vector2(320, 66)
	cont.add_theme_font_size_override("font_size", 24)
	cont.add_theme_color_override("font_color", Color(0.22, 0.15, 0.05))
	cont.add_theme_stylebox_override("normal", _flat(Color(0.98, 0.86, 0.45), Color(0.72, 0.58, 0.28), 12, 3))
	cont.pressed.connect(func() -> void:
		dim.queue_free()
		panel.queue_free()
		_show_game_over(victory))
	box.add_child(cont)


func hide_game_over_panel() -> void:
	if _over != null:
		_over.visible = false


func _on_spell_button_selected(spell: Dictionary) -> void:
	spell_selected.emit(spell)


func _on_team_selection_pressed() -> void:
	var gm: Node = get_node_or_null("/root/GameManager")
	if gm and gm.has_method("clear_custom_team"):
		gm.clear_custom_team()
	get_tree().change_scene_to_file("res://scenes/TeamSelection.tscn")


func _unhandled_key_input(event: InputEvent) -> void:
	if game_manager == null or not (event is InputEventKey) or not event.pressed or event.echo:
		return
	var k: int = (event as InputEventKey).keycode
	if k == KEY_SPACE or k == KEY_ENTER or k == KEY_KP_ENTER:
		end_turn_requested.emit()
	elif k == KEY_ESCAPE:
		if game_manager.selected_spell != null:
			game_manager.selected_spell = null
			game_manager.spell_selected.emit(null)
	elif k >= KEY_1 and k <= KEY_9 or k == KEY_0:
		var i: int = (k - KEY_1) if k != KEY_0 else 9
		if i >= 0 and i < _cards.size():
			spell_selected.emit(_cards[i].spell)
